-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.32-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             9.1.0.4867
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table polio_vacine.campaigns
CREATE TABLE IF NOT EXISTS `campaigns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_name` varchar(255) NOT NULL,
  `year` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `campaign_type` varchar(255) NOT NULL,
  `geographic_scope` text NOT NULL,
  `target_population` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table polio_vacine.campaigns: ~4 rows (approximately)
DELETE FROM `campaigns`;
/*!40000 ALTER TABLE `campaigns` DISABLE KEYS */;
INSERT INTO `campaigns` (`id`, `campaign_name`, `year`, `month`, `campaign_type`, `geographic_scope`, `target_population`, `created_at`) VALUES
	(1, 'test', 2011, 1, '', '', 0, '2025-01-11 15:55:40'),
	(2, 'polio', 3, 33, '', '3', 0, '2025-01-11 16:39:43'),
	(3, 'vacanie', 33, 3, '', '3', 0, '2025-01-11 16:40:10');
/*!40000 ALTER TABLE `campaigns` ENABLE KEYS */;


-- Dumping structure for table polio_vacine.coverage
CREATE TABLE IF NOT EXISTS `coverage` (
  `coverage_id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) NOT NULL,
  `coverage` decimal(5,2) NOT NULL,
  `submitted_by` int(11) NOT NULL,
  `submitted_at` datetime NOT NULL,
  PRIMARY KEY (`coverage_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table polio_vacine.coverage: ~3 rows (approximately)
DELETE FROM `coverage`;
/*!40000 ALTER TABLE `coverage` DISABLE KEYS */;
INSERT INTO `coverage` (`coverage_id`, `campaign_id`, `coverage`, `submitted_by`, `submitted_at`) VALUES
	(1, 1, 3.00, 0, '0000-00-00 00:00:00'),
	(2, 1, 3.00, 0, '0000-00-00 00:00:00'),
	(3, 1, 3.00, 0, '0000-00-00 00:00:00');
/*!40000 ALTER TABLE `coverage` ENABLE KEYS */;


-- Dumping structure for table polio_vacine.roles
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table polio_vacine.roles: ~2 rows (approximately)
DELETE FROM `roles`;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`id`, `role_name`) VALUES
	(1, 'admin'),
	(2, 'field');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;


-- Dumping structure for table polio_vacine.user
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_fullname` varchar(100) DEFAULT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `user_isactive` tinyint(1) DEFAULT 1,
  `phone` int(11) DEFAULT NULL,
  `user_token` varchar(200) DEFAULT NULL,
  `role_id` int(10) unsigned DEFAULT 6,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table polio_vacine.user: ~1 rows (approximately)
DELETE FROM `user`;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`user_id`, `user_fullname`, `user_email`, `user_password`, `mobile`, `district`, `user_isactive`, `phone`, `user_token`, `role_id`, `created_at`, `updated_at`) VALUES
	(83, 'kamran', 'kamran@rimes.int', '$2y$10$2e0g01UaoTYMrgStba2V.elDiQ9/IeI6nNnGUQSv6fwJiua3bonye', '33', NULL, 1, NULL, NULL, 1, '2025-01-11 16:09:58', '2025-01-11 16:09:58');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;


-- Dumping structure for table polio_vacine.vaccination_data
CREATE TABLE IF NOT EXISTS `vaccination_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) NOT NULL,
  `uc_id` int(11) NOT NULL,
  `vaccinated_children` int(11) NOT NULL,
  `missed_na` int(11) NOT NULL,
  `missed_refusals` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `campaign_id` (`campaign_id`),
  CONSTRAINT `vaccination_data_ibfk_1` FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table polio_vacine.vaccination_data: ~0 rows (approximately)
DELETE FROM `vaccination_data`;
/*!40000 ALTER TABLE `vaccination_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `vaccination_data` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
